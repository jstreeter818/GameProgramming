class Rectangle2{
    constructor(centerX, centerY, width, height){
        this.centerX = centerX
        this.centerY = centerY
        this.width = width
        this.height = height
    }
}

window.Rectangle2 = Rectangle2