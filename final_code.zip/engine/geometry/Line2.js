class Line2{
    constructor(one, two){
        this.one = one
        this.two = two
    }
}

window.Line2 = Line2