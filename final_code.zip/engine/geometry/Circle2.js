class Circle2{
    constructor(centerX, centerY, radius){
        this.centerX = centerX
        this.centerY = centerY
        this.radius = radius
    }
}

window.Circle2 = Circle2